# 36-task campaign

The campaign used only HART train and validation. H was not used for selection.

Locked selection candidates: E01, E02, E03, E04, E05, E06, E07, E25, E26, E30, E31.

The completed segment evaluated B0, cheap decision/sparse probes, multi-view inference, and two probability fusions.
Neural fine-tuning candidates E08-E24 were not started; they remain explicitly PLANNED rather than being represented as results.
